package com.example.comparator.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AgeComparatorDemo {

	public static void main(String[] args) {
		ArrayList<Student> stuList = new ArrayList<>();
		
		stuList.add(new Student(101, "Vijay", 23));
		stuList.add(new Student(106, "Ajay", 27));
		stuList.add(new Student(105, null, 21));
		stuList.add(new Student(106, "Prabu", 21));
		
		
	}

}

class Student implements Comparator<T>{
	private int rollNo;
	private String name;
	private int age;

	public Student(int rollNo, String name, int age) {
		this.rollNo = rollNo;
		this.name = name;
		this.age = age;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", age=" + age + "]";
	}

	@Override
	public int compare(T o1, T o2) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	

}
