package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Demo17 {
	public static void main(String[] args) {
//		 String[] geeks = {"Rahul", "Utkarsh","Shubham", "Neelam"};
//		 List<String> al = new ArrayList<String>(Arrays.asList(geeks));
//		 System.out.println(al);
//		 al.add("Shashank");
//		 al.add("Nishant");
//		 System.out.println("\nArrayList After adding two" +" more Geeks: ");
//		 System.out.println(al);
		
		Integer[] nums = {1,2,3,4,5,3,6,4};
  //		List<Integer> list = new ArrayList<>(Arrays.asList(nums));
//		System.out.println(list);
		
		//using for loop
		List<Integer> list2 = new ArrayList<>();
		for(Integer array:nums) {
			list2.add(array);
		}
		System.out.println(list2);
		System.out.println("Array "+list2.toArray());
		
	}

}
