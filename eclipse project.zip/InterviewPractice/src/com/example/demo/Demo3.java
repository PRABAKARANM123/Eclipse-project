package com.example.demo;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Demo3 {
	public static void main(String[] args) {
		Employee emp1 = new Employee("Ram", 22, 30000);
		Employee emp2 = new Employee("Kai", 24, 31000);
		Employee emp3 = new Employee("Prabu", 21, 35000);
		Employee emp4 = new Employee("Kabilan", 25, 40000);
		List<Employee> list = new ArrayList(Arrays.asList(emp1, emp2, emp3, emp4));

		
		
		Employee maxAge = list.stream().max((employee1, employee2)->employee1.getAge()>employee2.getAge()?1:-1).get();
		System.out.println(maxAge);

	}

}

class Employee {
	private String name;
	private int age;
	private int salary;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public Employee(String name, int age, int salary) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", salary=" + salary + "]";
	}
	
		
}
