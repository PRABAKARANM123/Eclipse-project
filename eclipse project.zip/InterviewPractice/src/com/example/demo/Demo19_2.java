package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Demo19_2 {
	public static void main(String[] args) {
		List<Book> bookList = new ArrayList<>();
		bookList.add(new Book(1, "JAVA", "Prabakaran"));
		bookList.add(new Book(2, "C", "Kavi"));
		bookList.add(new Book(3, "PYTHON", "Raj"));
		bookList.add(new Book(4, "JAVA", "MSP"));
		// List to map convertion using Stream API
		System.out.println(bookList);
		
		Map<Integer, String> mapList = bookList.stream().collect(Collectors.toMap(Book::getId, Book::getName));
		System.out.println(mapList);
		
		// List to Map convertion using for loop
		
		Map<Integer, String> map = new HashMap<>();
		for(Book book:bookList) {
			map.put(book.getId(), book.getName());
		}
		System.out.println("Map Using for loop "+map);

	}

}
class Book {
	private int id;
	private String name;
	private String author;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public Book(int id, String name, String author) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
	}
	
	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", author=" + author + "]";
	}
	
	
}