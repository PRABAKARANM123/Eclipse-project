package com.example.demo;

public class Demo29 {
	public static void main(String[] args) {
		int num = 15;
		int i=1;
		while(i<=num) {
			System.out.println(i);
			i++;
		}
	}
}
