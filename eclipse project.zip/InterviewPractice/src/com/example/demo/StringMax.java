package com.example.demo;

public class StringMax {
	public static void main(String[] args) {
		String[] names = {"Kavi", "raj","prabakaran"};
		String max = "";
		String min = names[0];
		for(int i=0; i<names.length; i++) {
			if(names[i].length()>max.length()) {
				max = names[i];
			}
			else if(names[i].length()<min.length()) {
				min = names[i];
			}
		}
		System.out.println(max);
		System.out.println(min);
	}

}
