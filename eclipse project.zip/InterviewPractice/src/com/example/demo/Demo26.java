package com.example.demo;

public class Demo26 {
	public static void main(String[] args) {
		int[] arr = {7,7,5,6,4,7,9,5};
		
		for(int i = 0; i < arr.length; i++) {  
            for(int j = i + 1; j < arr.length; j++) {  
                if(arr[i] == arr[j])  
                    System.out.println(arr[j]);  
            }  
        }  
	}

}
