package com.example.demo;

public class Demo28 {
	public static void main(String[] args) {
		for(int i=1; i<=20; i++) {
			
			if(i%3==0) {
				if(i%6==0) {
					System.out.println(i+"   3 & 6 FIZZ BUZZ");
				}
				System.out.println(i+"   3 FIZZ");
			}
//			else if(i%3==0) {
//				System.out.println(i+"FIZZ");
//			}
//			else if(i%3==0 && i%6==0) {
//				System.out.println(i+"FIZZ BUZZ");
//			}
		}
	}

}
