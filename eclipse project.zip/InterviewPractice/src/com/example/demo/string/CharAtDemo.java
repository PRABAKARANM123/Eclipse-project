package com.example.demo.string;

public class CharAtDemo {
	public static void main(String[] args) {
		String name = "PRABAKARAN";
		//System.out.println(name);
		int count = 0;
		int count2 = 0;

		for(int i=0; i<name.length(); i++) {
				char ch = name.charAt(i);
				if(ch == 'K') {
					System.out.println("count of A"+ch);
					count++;
					
				}
		}
		System.out.println(count);

	}

}
