package com.example.demo.string;

public class ReverseWord {
	public static void main(String[] args) {
		String name = "OneSoft";
		String rev = "";
		for(int i=name.length()-1; i>=0; i--) {
			rev = rev+name.charAt(i);
			//System.out.println(rev);
			
		}
		System.out.println(rev);
	}

}
