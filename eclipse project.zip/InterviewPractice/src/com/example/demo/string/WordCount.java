package com.example.demo.string;

public class WordCount {
	public static void main(String[] args) {
		String[] name = {"prabakaran"};
		int count = 0;
		for(int i=0; i<name.length; i++) {
			count++;
		}
		System.out.println(count);
	}

}
