package com.example.demo.string;

public class OneOneSeries {
	public static void main(String[] args) {
		int a = 1;
		for(int i=1; i<5; i++) {
			a = (a*10)+1;
			System.out.println(a);
		}
	}

}
