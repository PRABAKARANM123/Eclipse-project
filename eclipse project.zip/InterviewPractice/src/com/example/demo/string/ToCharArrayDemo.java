package com.example.demo.string;

public class ToCharArrayDemo {
	public static void main(String[] args) {
		String letters = "ABCDEFGHIJKLM";
		char[] let = letters.toCharArray();
		for(int i=0; i<let.length; i++) {
			System.out.println(let[i]);
		}
	}

}
