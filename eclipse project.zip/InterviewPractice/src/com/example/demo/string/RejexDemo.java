package com.example.demo.string;

public class RejexDemo {
	public static void main(String[] args) {
		String name = "My name is MSP and born in 2000";
		String[] words = name.split("\\s");
		
		for(int i=0; i<words.length; i++) {
			System.out.print(words[i]);
		}
	}

}
