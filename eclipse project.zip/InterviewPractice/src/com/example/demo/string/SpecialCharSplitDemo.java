package com.example.demo.string;

public class SpecialCharSplitDemo {
	public static void main(String[] args) {
		String m = "prabakaranMSP19@gmail.com";
		String numbers = "";
		String appLetter = "";
		String lowLetter = "";
		String sepcial = "";
		for(int i=0; i<m.length(); i++) {
			if(m.charAt(i)>='0'&& m.charAt(i)<='9') {
				//System.out.println("Numbers :"+m.charAt(i));
				numbers = numbers+m.charAt(i);
			}
			else if(m.charAt(i)>='A' && m.charAt(i)<='Z') {
				//System.out.println("ApperCase :"+m.charAt(i));
				appLetter = appLetter+m.charAt(i);
			}
			else if(m.charAt(i)>='a' && m.charAt(i)<='z') {
				//System.out.println("LowerCase :"+m.charAt(i));
				lowLetter = lowLetter+m.charAt(i);
			}
			else {
				//System.out.println("SpecialChar :"+m.charAt(i));
				sepcial = sepcial+m.charAt(i);
			}
		}
		System.out.println(numbers);
		System.out.println(appLetter);
		System.out.println(lowLetter);
		System.out.println(sepcial);

	}
}
