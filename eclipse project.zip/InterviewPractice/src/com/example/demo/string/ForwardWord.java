package com.example.demo.string;

public class ForwardWord {
	public static void main(String[] args) {
		String name = "OneSoft";
		String s = "";
		for(int i=0; i<name.length(); i++) {
			s = s+name.charAt(i);
			System.out.println(s);
		}
	}

}
