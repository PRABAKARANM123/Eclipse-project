package com.example.demo.string;

public class CountWordDemo {
	public static void main(String[] args) {
		String words = "I LOVE JAVA";
		int count = 1;
		System.out.println(words.contains("O"));
		System.out.println(words.startsWith("O"));
		System.out.println(words.endsWith("A"));



		
		for(int i=0; i<words.length(); i++) {
			char ch = words.charAt(i);
			if(ch==' ') {
				count++;
			}
		}
		System.out.println(count);
	}

}
