package com.example.demo;

public class PrimeDemo {
	public static void main(String[] args) {
		boolean prime = true;
		int num = 8;
		for(int i=2; i<num; i++) {
			if(num%i==0) {
				prime = false;
			}
		}
		if(prime == true) {
			System.out.println("prime");
		}
		else {
			System.out.println("Not Prime");
		}
	}

}
