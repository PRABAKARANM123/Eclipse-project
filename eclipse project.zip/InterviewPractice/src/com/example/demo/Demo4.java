package com.example.demo;

public class Demo4 extends A {
	public static void main(String[] args) {
		A demo = new Demo4();
		Demo4 demo1 = new Demo4();
		//Demo4 demo2 = new A(); // it not possible

		
		
	}

}

class A{
	
}
class B{
	
}
