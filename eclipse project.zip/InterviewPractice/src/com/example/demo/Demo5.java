package com.example.demo;

public class Demo5 {
	public static void main(String[] args) {
		int x = 10;
		int y = 20;
		
		y = y+x;
		x = y-x;
		y = y-x;
		System.out.println(x);
		System.out.println(y);
		
	}

}
