package com.example.demo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Demo19 {
	public static void main(String[] args) {
		Set<Integer> set = new HashSet<>();
		set.add(10);
		set.add(8);
		set.add(6);
		set.add(20);
		set.add(15);
		set.add(35);
		System.out.println(set);
		
		// Set to List
		List<Integer> list = new ArrayList<>(set);
		System.out.println(list);
		// List to Set
		Set<Integer> set2 = new HashSet<>(list);
		System.out.println(set2);
		
	}

}
