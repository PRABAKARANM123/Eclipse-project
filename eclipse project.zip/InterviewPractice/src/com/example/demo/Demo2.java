package com.example.demo;

 public class Demo2 {
	final int x;
	Demo2(){
		x=12;
	}

	public static void main(String[] args) {
		Demo2 value = new Demo2();
		System.out.println(value.x);
		 
	}
}
