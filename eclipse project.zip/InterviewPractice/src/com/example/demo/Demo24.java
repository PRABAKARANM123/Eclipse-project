package com.example.demo;

import java.util.Arrays;

public class Demo24 {
	public static void main(String[] args) {
		int a[] = {25,10,3,7,5};
		Arrays.sort(a);
		for(int i=0; i<a.length; i++) {
			System.out.println(a[i]);
		}
	}

}
