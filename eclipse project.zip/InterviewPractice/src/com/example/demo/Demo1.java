package com.example.demo;

public class Demo1 {
	public static void main(String[] args) {
		String a = "OneSoft";
		String b = new String(a);
		
		System.out.println(".equals method :"+a.equals(b));
		System.out.println("== method :"+a==b);
		System.out.println(a.hashCode());
		System.out.println(b.hashCode());
	}

}
