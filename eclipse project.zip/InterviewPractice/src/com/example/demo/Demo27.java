package com.example.demo;

public class Demo27 {
	public static void main(String[] args) {
		int a[] = {1, 2, 3, 4, 5};
		int num = 0;
		for(int i=0; i<=a.length; i++) {
			num = num+i;
		}
		System.out.println(num);
	}

}
