package com.example.demo;

public class ConnectTwoStrings {
	public static void main(String[] args) {
		//String name = "Raj";
		StringBuffer str = new StringBuffer("Hello");
		str.append("Java");
		System.out.println(str);
		
				
	}

}
