package com.example.demo;

public class SecondMax {
	public static void main(String[] args) {
		int[] a = {10,5,0,45,30,50};
		int firstMax = 0;
		int secondMax = 0;
		for(int i=0; i<a.length; i++) {
			if(a[i]>firstMax) {
				secondMax = firstMax;
				firstMax = a[i];
			}
			else if(a[i]>secondMax) {
				secondMax = a[i];
			}
		}
		System.out.println(firstMax);
		System.out.println(secondMax);

	}

}
