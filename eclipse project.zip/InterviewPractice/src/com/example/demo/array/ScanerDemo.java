package com.example.demo.array;

import java.util.Scanner;

public class ScanerDemo {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int[] nums = new int[n];
		for(int i=0; i<nums.length; i++) {
			nums[i] = s.nextInt();
		}
		for(int i=0; i<nums.length; i++) {
			int sum = nums.length*(nums.length+1)/2;
		}
		int sumOfArray = 0;
		
	}
}
