package com.example.demo.array;

public class SecondMax2 {
	public static void main(String[] args) {
		int[] a = {2,5,3,4,7,5,9};
		int firstMax = 0;
		int secondMax = 0;
		for(int i=0; i<a.length; i++) {
			if(a[i]>firstMax) {
				secondMax = firstMax;
				firstMax = a[i];
			}
			else if(a[i]>secondMax) {
				secondMax = a[i];
			}
		}
	}

}
