package com.example.demo.array;

public class PrimeNo {
	public static void main(String[] args) {
		int[] nums = {10,11,51,55};
		boolean prime = true;
		for(int i=0; i<nums.length; i++) {
			int nu = nums[1];
			for(int j=2; j<nu; j++) {
				if(nu%j==0) {
					prime = false;
				}
			}
			if(prime) {
				System.out.println("Prime");
			}
			else {
				System.out.println("Not");
			}
		}
		
		
		
		
		
		
		
		
		
		
		
//		boolean prime = true;
//		int nm = 11;
//		for(int i=2; i<nm; i++) {
//			if(nm%i==0) {
//				prime = false;
//			}
//		}
//		if(prime==true) {
//			System.out.println("prime No");
//		}
//		else {
//			System.out.println("Not Prime");
//		}
	}

}
