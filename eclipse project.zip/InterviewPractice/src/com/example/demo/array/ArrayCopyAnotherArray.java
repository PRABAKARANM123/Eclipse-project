	package com.example.demo.array;

public class ArrayCopyAnotherArray {
	public static void main(String[] args) {
		int[] a = {1,2,3,4,5};
		int[] b = new int[a.length];
		for(int i=0; i<a.length; i++) {
			b[i]=a[i];
		}
		for(int i=b.length-1; i>=0; i--) {
			System.out.println("Array b :"+b[i]);
		}
	}

}
