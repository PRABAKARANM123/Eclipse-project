package com.example.demo.array;

public class ArrayMax {
	public static void main(String[] args) {
		int[] nums = {45,65,74,21,45};
		int max = nums[1];
		for(int i=0; i<nums.length; i++) {
			if(nums[i]>max) {
				max = nums[i];
			}
		}
		System.out.println(max);
	}
}
