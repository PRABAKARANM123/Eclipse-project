package com.example.demo.array;

public class SecondMax3 {
	public static void main(String[] args) {
		int[] a = {4,3,8,6,-3,12,1};
		int firstMax = 0;
		int secondMax = 0;
		for(int i=0; i<a.length; i++) {
			if(a[i]>firstMax) {
				secondMax = firstMax;
				firstMax = a[i];

			}
			else if(a[i]>secondMax) {
				secondMax = a[i];
			}
		}
		System.out.println(firstMax);
		System.out.println(secondMax);
	}

}
