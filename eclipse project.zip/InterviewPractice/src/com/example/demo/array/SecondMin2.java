package com.example.demo.array;

public class SecondMin2 {
	public static void main(String[] args) {
		int[] a = {-10,12,54,8,-35,32,65,4,-45};
		int min = 0;
		int secondMin = 0;
		for(int i=0; i<a.length; i++) {
			if(a[i]<min) {
				secondMin = min;
				min = a[i];
			}
			else if(a[i]<secondMin) {
				secondMin = a[i];
			}
		}
		System.out.println(secondMin);
	}

}
