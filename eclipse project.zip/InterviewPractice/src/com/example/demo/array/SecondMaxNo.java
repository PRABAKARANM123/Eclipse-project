package com.example.demo.array;

public class SecondMaxNo {
	public static void main(String[] args) {
		int[] a = {10,30,20,45,25};
		int max;
		int size = a.length;
		for(int i=0; i<size; i++) {
			for(int j=i+1; j<size; j++) {
				if(a[i]>a[j]) {
					max = a[i];
					a[i] = a[j];
					a[j] = max;
				}		
			}
		}
		System.out.println("Secont Max :"+a[size-2]);
	}
}
