package com.example.demo.array;

public class ArrayMax2 {
	public static void main(String[] args) {
		int[] a = {45,10,78,2,5,54,1,-10};
		int max = 0;
		int min = a[0];
		for(int i=0; i<a.length; i++) {
			if(a[i]>max) {
				max = a[i];
				
			}
			else if(a[i]<min) {
				min = a[i];
			}
		}
		System.out.println(max);
		System.out.println(min);

	}

}
