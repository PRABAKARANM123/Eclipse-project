package com.example.demo;

public class Palindrom {
	public static void main(String[] args) {
		String name = "madam";
		String rev = "";
		for(int i=name.length()-1; i>=0; i--) {
			rev = rev+name.charAt(i);
		}
			if(name.equalsIgnoreCase(rev)) {
				System.out.println("It is a Palindrom");
			}
			else {
				System.out.println("Not palindrom");
			}
		}
	

}
