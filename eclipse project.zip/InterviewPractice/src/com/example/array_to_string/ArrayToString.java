package com.example.array_to_string;

import java.util.Arrays;
import java.util.stream.Collectors;

public class ArrayToString {
	public static void main(String[] args) {
		// 4 ways we can convert Array To String
		
		// Using Arrays.toString() method
		String[] nameArray = { "My", "name", "is", "Prabakaran", "!" };
		String string1 = convertArrayToStringUsingtoString(nameArray);
		System.out.println("convert using toString() :"+string1);
		
		// Using StringBuilder.append method
		String string2 = convertArrayToStringUsingAppend(nameArray);
		System.out.println("using stringBuilder :"+string2);
		
		// Using String.join() method
		String string3 = convertArrayToStringUsingJion(nameArray);
		System.out.println("using String.join() :"+string3);
		
		// Using Collctors.joining() method
		String string4 = convertArrayToStringUsingCollctorsJoining(nameArray);
		System.out.println("using Collectors.joining() :"+string4);


	}
	
	
	// using Arrays.toString method
	public static String convertArrayToStringUsingtoString(String[] stringArray) {
		return Arrays.toString(stringArray);
	}
	
	// Using StringBuilder.append method
	public static String convertArrayToStringUsingAppend(String[] stringArray) {
		StringBuilder strBuilder = new StringBuilder();
		for(int i=0; i<stringArray.length; i++) {
			strBuilder.append(stringArray[i]);
		}
		return strBuilder.toString();
	}
	
	// Using String.join() method
	public static String convertArrayToStringUsingJion(String[] stringArray) {
		String stringJoin = String.join("   ", stringArray);
		return stringJoin;
	}
	
	// Using Collctors.joining() method
	public static String convertArrayToStringUsingCollctorsJoining(String[] stringArray) {
		String stringJoining = Arrays.stream(stringArray).collect(Collectors.joining());
		return stringJoining;
	}

}
