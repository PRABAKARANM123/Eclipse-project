package For1;

public class sQuarValues {
	public static void main(String[] args) {
		for(int i=2; i<=10; i++) {
			System.out.println("Squar Of "+i+" Is "+i*i);
			
		}
	}

}
