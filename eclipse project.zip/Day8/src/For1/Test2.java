package For1;

public class Test2 {
	public static void main(String[] args) {
		String name="onesoft";
		for(int i=name.length()/2; i>=0; i--) {
			System.out.println(name.charAt(i));
		}
	}

}
