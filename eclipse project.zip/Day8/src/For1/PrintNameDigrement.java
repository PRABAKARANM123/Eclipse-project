package For1;

public class PrintNameDigrement {
	public static void main(String[] rgs) {
		for(int i=5; i>=1;i--) {
			System.out.println(i);
		}
	}

}
