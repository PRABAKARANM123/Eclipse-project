package For1;

public class StringLoopRevers {
	public static void main(String[] args) {
		String name = "Onesoft";
		for(int i=name.length()-1; i>=0; i--) {
			System.out.println(name.charAt(i));
			
		}
		// System.out.println(name.charAt(i));
	}

}
