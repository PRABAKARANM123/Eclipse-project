package For1;

public class StringLoop {
	public static void main(String[] args) {
		String name = "Onesoft";
		for(int i=0;i<name.length(); i++) {
			System.out.println(name.charAt(i));
		}
	}

}
