package For1;

public class FindTotal {
	public static void main(String[] args) {
		int total = 0;
		for(int i = 1; i<=10; i++) {
			total = total+i;
			System.out.println(total);
		}
		//System.out.println(total);
	}

}
