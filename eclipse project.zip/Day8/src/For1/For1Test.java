package For1;

public class For1Test {
	public static void main(String[] args) {
		int num=10;	
		for(int i=1; i<=num; i++) {
			System.out.print("*");
			
	}

}
}
