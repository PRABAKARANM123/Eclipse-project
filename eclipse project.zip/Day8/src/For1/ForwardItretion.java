package For1;

public class ForwardItretion {
	public static void main(String[] args) {
		for(int i =50; i<=150; i++) {
			System.out.println(i);
		}
	}

}
