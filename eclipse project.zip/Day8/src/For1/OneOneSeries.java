package For1;

public class OneOneSeries {
	public static void main(String[] args) {
		int num = 1;
		for(int i=1; i<=5; i++) {
			System.out.println(num);
			num = (num*10)+1;
			//System.out.println(num);
		}
		//System.out.println(num);
	}

}
