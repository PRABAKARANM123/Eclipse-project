package For1;

public class ThreeThreeSeries {
	public static void main(String[] args) {
		int num =3;
		//int num2 =3;
		for(int i=1; i<=5; i++) {
			System.out.println(num);
			num=(num*10)+3;
		}
	}

}
