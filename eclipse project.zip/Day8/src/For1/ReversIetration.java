package For1;

public class ReversIetration {
	public static void main(String[] args) {
		
	}

}
