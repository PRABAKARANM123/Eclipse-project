package For1;

public class cubeValues {
	public static void main(String[] args) {
		for(int i=10; i<=15; i++) {
			System.out.println("Cube of "+i+" is "+i*i*i);
		}
	}

}
