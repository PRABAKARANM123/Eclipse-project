  package For1;
public class FindFibonacciSeries {
	public static void main(String[] args) {
	   
	}

}
