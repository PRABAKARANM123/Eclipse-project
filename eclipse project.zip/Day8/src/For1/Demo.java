package For1;

public class Demo {
	public static void main(String[] args) {
	String names = "Madhu age is 21 born in 2000";
	//String[] words = names.split("\\D");
	//String[] words = names.split("\\d");
	String[] words = names.split("a");
	//String[] words = names.split("\\s");
	for(int i=0; i<words.length; i++) {
		System.out.print(words[i]);
	}
	}
}
