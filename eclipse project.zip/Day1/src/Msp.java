
public class Msp {
	public static void main(String[] args) {
		String[] m = args[0].split(",");
		String n = m[0].toUpperCase();
		System.out.println(n);
	}
}