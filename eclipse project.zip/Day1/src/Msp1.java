
public class Msp1 {
	public static void main(String[] args) {
		String a=args[0];
		char[] b=a.toCharArray();
		
		for(int i=0;i<b.length;i++) {
		}
		
			
		
		
		System.out.println(b.length);
		
	}

}
