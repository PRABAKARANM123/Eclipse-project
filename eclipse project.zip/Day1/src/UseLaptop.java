
public class UseLaptop {
	public static void main(String[]args) {
		Laptop laptop1 = new Laptop();
		laptop1.brand="HP";
		
		System.out.println(laptop1.brand);
		
	}

}
