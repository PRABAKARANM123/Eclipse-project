
public class Employee {
	int id;
	String name;
	String designation;
	float salary;
	long phone;

}
