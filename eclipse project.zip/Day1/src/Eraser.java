
public class Eraser {
	String brand;
	int price;
	boolean isQuality;
}


