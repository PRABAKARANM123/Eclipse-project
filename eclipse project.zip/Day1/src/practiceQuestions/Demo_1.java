package practiceQuestions;

public class Demo_1 {

}
