package practiceQuestions;

public class CountOfIteration {
	public static void main(String[] args) {
		int count = 0;
		for(int i=1; i<=6; i++) {
			count = count+1;
			
		}
		System.out.println(count);
	}

}
