package practiceQuestions;

public class Qustion6 {

}
