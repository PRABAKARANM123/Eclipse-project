package practiceQuestions;

public class Square {
	public static void main(String[] args) {
		int num = 0;
		for(int i=1; i<=5; i++) {
			//System.out.println(i*i);
			int n = i*i;
			num = num+n;
		}
		System.out.println(num);
	}

}
