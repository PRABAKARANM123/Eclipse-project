package practiceQuestions;

public class Pen {
	String brand;
	int price;
	boolean isBlueColour;
	float tipWidth;
	
}
