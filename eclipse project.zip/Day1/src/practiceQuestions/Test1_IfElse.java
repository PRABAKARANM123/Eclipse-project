package practiceQuestions;

public class Test1_IfElse {
	public static void main(String[] args) {
	int num = 40; int num2 = 30;
	if(num>50) {
		if (num2>40) {
			System.out.println("Eligible");
		}
		else {
			System.out.println("Not Eligible");
		}
		
		
			
		}
	else {
		System.out.println("Invalid");
	}
	}
 
		
}

	
