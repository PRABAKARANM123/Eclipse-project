package practiceQuestions;

public class Student {
	String name;
	int id;
	int age;
	String clas;
	int attePercent;
	int nODPresent;
	int totalWorkingDays;
	int p;
	
	

}
