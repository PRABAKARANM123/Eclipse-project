package practiceQuestions;

public class Test_2_SwitchCase {
	public static void main(String[] args) {
//		int day = 5;
//		switch(day) {
//		case 1:System.out.println("Monday");
//		case 2:System.out.println("Tuesday");
//		case 3:System.out.println("Wednesday");
//		case 4:System.out.println("Thursday");
//		case 5:System.out.println("Friday");break;
//		case 6:System.out.println("Saterday");
//		case 7:System.out.println("Sunday");break;
//		default:System.out.println("Invalid");
//		}
		
		int day = 2;
		String dayString;
		switch(day) {
		case 1:dayString = "Monday";break;
		case 2:dayString = "Tuesday";break;
		case 3:dayString = "Wednesday";break;
		case 4:dayString = "thursday";break;
		//default: dayString = "Invalid";
		}
		//System.out.println(dayString);
	}

}
