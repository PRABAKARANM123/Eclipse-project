package practiceQuestions;

public class Flask {
	String brand;
	int price;
	boolean isSteelType;

}
