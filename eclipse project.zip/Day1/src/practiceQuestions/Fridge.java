package practiceQuestions;

public class Fridge {
	String brand;
	String color;
	int price;
	boolean isWarranty;
	

}
