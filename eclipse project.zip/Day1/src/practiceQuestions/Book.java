package practiceQuestions;

public class Book {public static void main() {
	
}

}
