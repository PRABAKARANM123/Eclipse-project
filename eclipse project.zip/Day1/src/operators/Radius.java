package operators;

public class Radius 
	{
	public static void main(String[]args)
	{
	int radius=2;
	float pi=3.14f;
	//double a=12598d;
	double d=radius*radius*pi;
	System.out.println(d);
	
	//System.out.println(radius*radius*3.14d);
	
	}
	}
