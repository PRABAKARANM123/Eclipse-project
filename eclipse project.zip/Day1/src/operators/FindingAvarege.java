package operators;

public class FindingAvarege {
	public static void main(String[]args) {
		String name="PRABAKARAN";
		char initial='M';
	 String roleNum="13ME110";
	int maths=79;
	double phy=98.5d;
	int tamil=82;
	int bio=66;
	double avarege=(maths+phy+tamil+bio)/4d;
	System.out.println ("Studen Name = "+name);
	System.out.println("student initial = "+initial);
	System.out.println(avarege);
	
		
		
	}

}
