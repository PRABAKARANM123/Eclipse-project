package operators;

public class findingsquars {
	public static void main(String[]args) {
		int num1=12;
		int value=num1*num1;
		System.out.println(value);
		
	}

}
