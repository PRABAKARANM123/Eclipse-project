package operators;

public class DiffBetweenTwoValues{
	public static void main(String[]args)
	{
		long a=9597178747l;
		long b=9597178745l;
		long c=a-b;
		String d="DiffOfTwoNumber=";
		System.out.println("A="+a);
		System.out.println("B="+b);
		System.out.println(d+c);
		
		
		
		
		
	}

}
