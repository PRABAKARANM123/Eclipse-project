package operators;

public class relationaloperator {
	public static void main(String[]args) {
		int num1=568;
		int num2=452;
		boolean greater=num1>num2;
		boolean lesser=num1<num2;
		boolean greaterEqual=num1>=num2;
		boolean lesserEqual=num1<=num2;
		boolean equalEqual=num1==num2;
		boolean notEqual=num1!=num2;
		System.out.println(greater);
		System.out.println(lesser);
		System.out.println(greaterEqual);
		System.out.println(lesserEqual);
		System.out.println(equalEqual);
		System.out.println(notEqual);
	}
	

}
