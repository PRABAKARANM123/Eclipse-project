package operators;

public class findingcubs {
	public static void main(String[]args) {
		int num=12;
		int num1=num*num*num;
		System.out.println(num1);
		
		
	}

}
