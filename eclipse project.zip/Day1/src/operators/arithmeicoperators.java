package operators;

public class arithmeicoperators{
	public static void main(String[]args){
		int number1=50;
		int number2=25;
	
		int sub = number1-number2;
		int divide=number1/number2;
		int multiply=number1*number2;
		int modulus=number1%number2;
	
		System.out.println(sub);
		System.out.println(divide);
		System.out.println(multiply);
		System.out.println(modulus);
		
	}
	

}
