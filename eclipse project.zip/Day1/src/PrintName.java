
public class PrintName {
	public static void main(String[] args) {
		String[] n = args[0].split(",");
		String b = n[0];
		//char d = b[0];
		//char c = b.toChraArray();
		//char[] c = n.toCharArray();
		System.out.println(b);		
		
		
		
		
		
	}

}
