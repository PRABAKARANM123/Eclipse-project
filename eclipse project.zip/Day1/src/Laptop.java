public class Laptop {
	String brand;
	int price;
	String model;
	boolean isAirBags;
	boolean isDiskBreak;
	int millege;
}
