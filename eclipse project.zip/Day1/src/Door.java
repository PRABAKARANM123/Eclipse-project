
public class Door {
	String color;
	String materialType;
	Boolean isSmartLockType;

}
