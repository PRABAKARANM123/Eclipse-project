package for1;

public class Demo {
	Integer a = new 

}
