package datatype;

public class StudentDetail {
	public static void main(String[] args) {
		String name="Prabakaran M";
		int rollNumber=345;
		long mobileNumber=9865735684l;
		String dateOfBirth="19.04.1991";
		System.out.println(name);
		System.out.println(rollNumber);
        System.out.println(mobileNumber);
	}
}
