package datatype;

public class EmployeeDtails {
	public static void main(String[]args){
		String employeeName="PRABAKARAN M";
		int employeeId=2568;
		int employeeSalary=45000;
		long employeeMobileNumber=9874528745l;
		boolean isGoodBehaviour=true;
		int employeeHeight=70;
		float employeeWeight=68.4f;
		System.out.println(employeeName);
		System.out.println(employeeId);
		System.out.println(employeeSalary);
		System.out.println(employeeMobileNumber);
		System.out.println(isGoodBehaviour);
		

		
	}

}
