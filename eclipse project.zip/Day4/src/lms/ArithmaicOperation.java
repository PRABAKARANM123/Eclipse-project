package lms;

public class ArithmaicOperation {
	public static void main(String[]args)
	{
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		System.out.println("Addition:"+(num1+num2));
		System.out.println("Substraction:"+(num1-num2));
		System.out.println("Multiplication:"+(num1*num2));
		System.out.println("Divition:"+(num1/num2));
		System.out.println("Module:"+(num1%num2));
	}

}
 