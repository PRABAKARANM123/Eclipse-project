package ifelse_conditions;

public class FindThePositiveNumbr {
	public static void main(String[] args) {
		int number = -10;
		if(number>0) {
			System.out.println("PASITIVE");
			
		}
		else {
			System.out.println("NEGATIVE");
		}
	}

}
