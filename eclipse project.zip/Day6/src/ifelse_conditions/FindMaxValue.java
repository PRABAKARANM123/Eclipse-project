package ifelse_conditions;

public class FindMaxValue {
	public static void main(String[] args) {
		int number1 = 30;
		int number2 = 20;
		if (number1>number2) {
			System.out.println("MAXIMUM");
		}
		else {
			System.out.println("NOT A MAXIMUM");
		}
	}

}
