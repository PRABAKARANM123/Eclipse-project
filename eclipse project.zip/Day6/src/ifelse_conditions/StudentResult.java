package ifelse_conditions;

public class StudentResult {
	public static void main(String[] args) {
		int mark = 70;
		if(mark>60) {
			System.out.println("PASS");
		}
		else {
			System.out.println("FAIL");
		}
	}

}
