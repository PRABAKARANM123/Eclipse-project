package ifelse_conditions;

public class FindTheTotal {
	public static void main(String[] args) {
		int num1 = 5;
		int num2 = 7;
		int num3 = 10;
		if (num1+num2 == num3) {
			System.out.println("IS EQUAL");
		}
		else {
			System.out.println("NOT EQUAL");
		}
	}

}
