package ifelse_conditions;

public class FindEvenNumber {
	public static void main(String[] args) {
		int number = 11;
		if(number%2==0) {
			System.out.println("EVEN NUMBER");
			
		}
		else {
			System.out.println("NO A EVEN NUMBER");
		}
	}

}
