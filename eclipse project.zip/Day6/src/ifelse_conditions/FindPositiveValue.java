package ifelse_conditions;

public class FindPositiveValue {
	public static void main(String[] args) {
		int number = -5;
		if(number>0) {
			System.out.println(number+15);
		}
		else {
			System.out.println(number-15);
		}
	}

}
