package ifelse_conditions;

public class Shapes { 
	public static void main(String[] args) {
		int length = 7;
		int breadth = 7;
		if(length==breadth) {
			System.out.println("SQUAR");
		}
		else {
			System.out.println("NOT A SQUAR");
		}
	}

}
