package ifelse_conditions;

public class riteirmenAge {
	public static void main(String[] args) {
		int age = 48;
		if(age>=58)
		{
			System.out.println("HE IS ELIGIBLE");
			
		}
		else {
			System.out.println("HE IS NOT ELIGIBLE");
			
		}
	}

}
