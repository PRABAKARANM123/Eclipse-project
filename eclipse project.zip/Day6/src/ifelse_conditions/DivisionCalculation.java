package ifelse_conditions;

public class DivisionCalculation {
	public static void main(String[] args) {
		int number = 25;
		if(number%4==0&&number%5==0) {
			System.out.println("dIVISIBLE 4&5");
		}
		else {
			System.out.println("NOT DIVISIBLE 4&5");
		}
	}

}
