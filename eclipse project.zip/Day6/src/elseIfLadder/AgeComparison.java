package elseIfLadder;

public class AgeComparison {
	public static void main(String[] args ) {
		int age = 15;
		if (age>0&&age<=13) {
			System.out.println("KID");
			
		}
		else if(age>13&&age<=20) {
			System.out.println("ADULT");
		}
	}

}