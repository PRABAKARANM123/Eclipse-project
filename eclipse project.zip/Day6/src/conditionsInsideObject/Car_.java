package conditionsInsideObject;

public class Car_ {
	String brand;
	int price;
	String color;
	

}
