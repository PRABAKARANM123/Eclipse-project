package conditionsInsideObject;

public class Bike {
	String brand;
	int price;
	String color;
	int taxPrice;

}
