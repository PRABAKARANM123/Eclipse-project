package conditionsInsideObject;

public class Watch {
	String brand;
	int price;
	String color;
	boolean isWarranty;
	String strap;
	String material;
}


