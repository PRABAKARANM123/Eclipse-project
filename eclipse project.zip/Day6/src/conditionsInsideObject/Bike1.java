package conditionsInsideObject;

public class Bike1 {
	String brand;
	int price;
	String color;
	int taxPrice;

}


