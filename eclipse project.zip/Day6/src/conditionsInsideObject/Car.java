package conditionsInsideObject;

public class Car {

		String brand;
		int price;
		String color;
		boolean isAutomaticGear;
		
	}

