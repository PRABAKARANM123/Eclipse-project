package functions;

public class UseMaxNumber {
	public static void main(String[] args) {
		int[] nums = {50, 16, 58, 30, 48};
		MaxNumber max = new MaxNumber();
		System.out.println(max.findMaxNumber(nums));
	}

}
