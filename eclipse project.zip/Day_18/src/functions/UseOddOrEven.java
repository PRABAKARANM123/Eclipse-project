package functions;

public class UseOddOrEven {
	public static void main(String[] args) {
		int[] nums = {50, 71, 32, 75, 40, 91, 73};
		OddOrEven num = new OddOrEven();
		num.findOddOrEven(nums);
		
	}

}
