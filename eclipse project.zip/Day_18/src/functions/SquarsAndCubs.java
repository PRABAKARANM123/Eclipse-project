package functions;

public class SquarsAndCubs {
	int num1=23;
	public int findSquar() {
	
		return num1*num1;
	}
	
public int findCub() {

		return num1*num1*num1;
	}

}
