package functions;

public class UseSquarsAndCubs {
	public static void main(String[] args) {
		SquarsAndCubs num = new SquarsAndCubs();
		System.out.println(num.findSquar());
		System.out.println(num.findCub());
		
	}

}
