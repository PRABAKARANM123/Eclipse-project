package polymorpisam;

public class UseMaximum {
	public static void main(String[] args) {
		Maximum max = new Maximum();
		System.out.println(max.findMaximum(100, 250));
		System.out.println(max.findMaximum(100, 250, 350));
		System.out.println(max.findMaximum("BMW", "Tata"));
	}

}
