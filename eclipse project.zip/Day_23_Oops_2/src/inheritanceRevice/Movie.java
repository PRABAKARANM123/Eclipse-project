package inheritanceRevice;

public class Movie {
	String movieType(String type) {
		
		return type;
	}
	int length(int num) {
		return num;
	}

}
