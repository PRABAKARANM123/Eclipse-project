package inheritanceRevice;

public class LandLine {
	public void call() {
		System.out.println("Calling");
	}

}
