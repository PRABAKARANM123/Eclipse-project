package Polymorphism;

public class RBIBank {
		public int getInterest(int amount, int interest) {
			return amount-interest;
			
		}
	

}
