package Polymorphism;

public class Movie {
	public String getFightSequance(int fight) {
		return fight+" Fight have in this Movie";
	}

}
