package firstProject;

public class HolloWorldDemo {
	public static void main(String[] args) {
		System.out.println("Hollo World");
	}

}
