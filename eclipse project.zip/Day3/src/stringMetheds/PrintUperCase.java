package stringMetheds;

public class PrintUperCase {
	public static void main(String[]args)
	{
	String name="prabakaran";
	String result=name.toUpperCase();
	System.out.println(result);
	}

}
