package stringMetheds;

public class CeckContains {
	public static void main(String[]args)
	{
		String name="onesoft";
		boolean result=name.contains("so");
		System.out.println(result);
			
		
	}

}

