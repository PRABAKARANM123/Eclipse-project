package stringMetheds;

public class GetWords {
	public static void main(String[]args)
	{
		String name="ELECTRONICS AND COMMUNICATION";
		String answer=name.substring(16);
		System.out.println(answer);
	}

}
