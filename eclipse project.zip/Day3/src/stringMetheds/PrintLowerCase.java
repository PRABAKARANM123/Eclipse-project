package stringMetheds;

public class PrintLowerCase {
	public static void main(String[]args) {
		String name="PRABAKARAN";
		//String result=name.toLowerCase();
		//System.out.println(result);
		System.out.println(name.toLowerCase());
	}   

}
