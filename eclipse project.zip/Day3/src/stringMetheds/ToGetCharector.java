package stringMetheds;

public class ToGetCharector {
	public static void main(String[]args)
	{
		String name="PRABAKARAN";
		char letter=name.charAt(7);
		System.out.println(letter);
		System.out.println(name.charAt(3));
		
	
	
	
		
	}

}
