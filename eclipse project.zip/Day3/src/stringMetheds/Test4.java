package stringMetheds;

public class Test4 {
	public static void main(String[]args)
	{
		String name="CAT";
		char[]letters=name.toCharArray();
		System.out.println(letters[0]);
		System.out.println(letters[1]);
		System.out.println(letters[2]);
		System.out.println(letters[0]+"  "+letters[1]+" "+letters[2]);
	}

}
