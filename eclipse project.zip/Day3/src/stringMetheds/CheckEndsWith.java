package stringMetheds;

public class CheckEndsWith {
	public static void main(String[]srgs)
	{
		String name="ONESOFT";
		boolean result=name.endsWith("ESOFT");
		System.out.println(result);
	}

}
