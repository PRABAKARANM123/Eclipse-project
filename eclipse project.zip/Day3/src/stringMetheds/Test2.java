package stringMetheds;

public class Test2 {
	public static void main(String[]args)
	{
		String name="communication";
		//char letter=name.charAt(name.length()-1);
		//System.out.println(letter);
		char let = name.charAt(1);
		System.out.println(name.charAt(name.length()-1));
		System.out.println(let);
		
	}

}
