package stringMetheds;

public class Test5 {
	public static void main(String[]args)
	{
		String word="My/little/world";
		//String[] words=word.split("/");
	    //char[]letter=words[0].toCharArray();
	    char[] let = word.toCharArray();
	    //System.out.println(letter[0]);
	    //System.out.println(letter[1]);
		System.out.println(let);
		System.out.println(let[2]);
		System.out.println(let[4]);
	}
	    
	    
	

}
         
