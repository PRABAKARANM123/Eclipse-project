package stringMetheds;

public class CheckEqualsIgnoreCase {
	public static void main(String[]args)
	{
		String name="ONESOFT";
		boolean result=name.equalsIgnoreCase("oNESOFT");
		System.out.println(result);
				
	}

}
