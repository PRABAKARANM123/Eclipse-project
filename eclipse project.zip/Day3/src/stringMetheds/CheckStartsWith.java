package stringMetheds;

public class CheckStartsWith {
	public static void main(String[]args)
	{
		String name="ONESOFT";
		boolean result=name.startsWith("ON");
		System.out.println(result);
	}

}
