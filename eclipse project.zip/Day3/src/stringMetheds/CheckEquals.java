package stringMetheds;

public class CheckEquals {
	public static void main(String[]args)
	{
		String name="ONESOFT";
		boolean result=name.equals("ONESOFT");
		System.out.println(result);
	 
	}

}
