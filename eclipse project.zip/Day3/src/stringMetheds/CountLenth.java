package stringMetheds;

public class CountLenth {
	public static void main(String[]args)
	{
		String name="PRABAKARAN";
		int length=name.length();
		System.out.println(length);
	}

}
