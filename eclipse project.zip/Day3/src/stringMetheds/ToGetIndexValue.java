package stringMetheds;

public class ToGetIndexValue {
	public static void main(String[]args)
	{
		String name="PRABAKARAN";
		int position=name.indexOf('R');
		System.out.println(position);
	}

}
