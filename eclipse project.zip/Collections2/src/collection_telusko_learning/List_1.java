package collection_telusko_learning;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// * List is an Interface which extents Collection which have some extra features and it follow index based
// * List allow sort() method
// * List allow fetch values and set values on index based but Collection does not allow

public class List_1 {
	public static void main(String[] args) {
		List<Integer> values = new ArrayList<>();
		values.add(45);
		values.add(88);
		values.add(2);
		values.add(22);
		
//		values.add("Ram");
//		values.add("Arul");
//		values.add("Prabu");
		
		Collections.sort(values); // * It sort Assending order
		
		values.forEach(System.out::println); // It Iterate the values
		
//		for(Integer i:values) {
//			System.out.println(i);
//		}

	}
}
