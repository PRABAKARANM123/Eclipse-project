package collection_telusko_learning;

import java.util.Vector;
// * Vector is implemented in List interface
// * Vector increase the size Dynamically
// * Vector default size is 10
// * when Vector exceed there limit it Increase the size 100% or double
// * Vector is Synchronized so it is Thread safe not practically but theoryticaly may affect Thread

// * ArrayList increase the capacity by 50%, so it reduce memory waste
// * ArraList not Thread safe
// * It is faster perfomence compare to Vector
// * ArrayList initial capacity is 10
public class Vector_ArrayList {
	public static void main(String[] args) {
		Vector v = new Vector();
		v.add(45);
		v.add(87);
		v.add(45);
		v.add(87);
		v.add(45);
		v.add(87);
		v.add(45);
		v.add(87);
		v.add(45);
		v.add(87);
		v.add(75); // * when enter the 11th element it increase the size by 20
		           // * When enter the 21th element it increase the size by 40
		v.remove(1);
		System.out.println(v.capacity()); // * capacity() method is used to find size of the Vector
		for(Object i:v) {
			System.out.println(i);
		}
		
		
	}

}
