package collection_telusko_learning;



//class Container<T> { // when we create object for the Container and assine it for int value it considerd integer type Container
 class Container<T extends Number>{
	T value;
	public void show() {
		System.out.println(value.getClass().getName());
	}
}

public class Generics {
	public static void main(String[] args) {
		// when specify generic is integer in above 'T' becomes Integer and value becomes Integer
		// when we extend number we can assine all numbers like float, int, double,etc because all are came from number Class
		Container<Integer> obj = new Container<>(); 
		obj.value = 5;
		obj.show();
	}
}
	
	

