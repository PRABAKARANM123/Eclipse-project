package collection_telusko_learning;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
// * Collection is an Interface and ArrayList is implement class of Collection Interface
// * Collection does not work index based
// * Collection maintain the sequence of insertion order
// * sort() method does not support collection

public class Collection_1 {
	public static void main(String[] args) throws Exception {
		Collection values = new ArrayList();
		// * Collection<Integer> values = new ArrayList<>(); // it support only an Integer
		values.add(5);
		values.add("Ram");
		values.add(5.6);
		values.add('k');
		
//		Iterator i = values.iterator();
//		while(i.hasNext()) { // 'hasNext' is check the next element whether it has print that element or it stop the loop
//			System.out.println(i.next());// 'next' is print the element
//		}
		//for(Integer i:values) {
		for(Object i:values) { // Object is super class of all the class, so it support all the values
			System.out.println(i);
		}
	}
// * we can fetch the value from Collection by using 'Iterator', 'Enhance for loop', 'forEach lambda'
}
