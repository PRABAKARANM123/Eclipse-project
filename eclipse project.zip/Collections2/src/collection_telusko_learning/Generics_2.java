package collection_telusko_learning;

import java.util.ArrayList;

class Container_1<T extends Number>{
	T value;
	public void demo(ArrayList<? extends T> obj) {
		// we can replace 'extend' by 'super'
		// extend mean '?' is subclass of 'T'
		// super mean '?' is super class of 'T' but sub class 
	}
}




public class Generics_2 {
	public static void main(String[] args) {
		Container_1<Number> obj = new Container_1<>();
		obj.demo(new ArrayList<Integer>());
	}

}
