package map_Interface_Telusko;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo_2 {
	public static void main(String[] args) {
		Map<String, String> phoneBook = new HashMap<>();
		phoneBook.put("Prabu", "915473652");
		phoneBook.put("Kavi", "9854635241");
		phoneBook.put("Raj", "9678635241");
		phoneBook.put("Kamesh", "9758635241");
		phoneBook.put("Hari", "9156635241");
		
		System.out.println(phoneBook.get("Kavi"));
		System.out.println(phoneBook.values());
		System.out.println(phoneBook.entrySet());
		
		//Set<String> keys = phoneBook.keySet();
		
		for(String i:phoneBook.keySet()) {
			System.out.println(i+"  "+phoneBook.get(i));
		}
		
	
	}

}
