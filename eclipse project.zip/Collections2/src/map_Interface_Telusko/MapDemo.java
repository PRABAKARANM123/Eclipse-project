package map_Interface_Telusko;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class MapDemo {
	public static void main(String[] args) {
		//Map<String, String> map = new HashMap<>(); // * HashMap is Non Synchronized so it is not thread safe
		Map<String, String> map = new Hashtable<>(); // * Hashtable is Synchronized so thread safe
		map.put("myName", "Prabakaran");             
		map.put("actor", "Ajith");
		map.put("ceo", "Sundhar");
		
		for(String key:map.keySet()) {
			System.out.println(key+"  "+map.get(key));
		}
	}

}
