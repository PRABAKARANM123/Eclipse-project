package map_Interface_Telusko;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Map_EntryDemo {
	public static void main(String[] args) {
		Map<String, String> phoneBook = new HashMap<>();
		phoneBook.put("Prabu", "915473652");
		phoneBook.put("Kavi", "9854635241");
		phoneBook.put("Raj", "9678635241");
		phoneBook.put("Kamesh", "9758635241");
		phoneBook.put("Hari", "9156635241");
		
		// * HashMap not Thread safe
		// * Hashtable is Tread safe
		// * Linked HashMap follows insertion order
		// * TreeHashMap provide sorted format map
		Set<Map.Entry<String, String>> values = phoneBook.entrySet();
		System.out.println(values);
		
		for(Map.Entry<String, String> e:values) {
			System.out.println(e.getKey()+"  "+e.getValue());
			e.setValue("III");
			System.out.println();
		}
	}

}
