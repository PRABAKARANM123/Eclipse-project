package set_Interface_telusko;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
	public static void main(String[] args) {
//		Set<Integer> values = new HashSet<>();
		Set<Integer> values = new TreeSet<>();
		values.add(5);
		values.add(10);
		values.add(64);
		values.add(5); // * Set does not allow duplicate values
		values.add(8); // * Set does not follow insertion order and follow Hasing Tegniqu
					   // * TreeSet follow insertion order and does not allow duplicates
		for(int i:values) {
			System.out.println(i);
		}
		
	}

}
