package java_8_Features_Default_Telusko;

public interface InterfaceDemo_2 {
	default void show() {
		// * when implement an interface we con't implements two 'Interfaces
	}

}
interface Test{
//	default void show() {
//	}
	
}
class C implements InterfaceDemo_2,Test {
     // * the method 'show' we defined in Interface so we need not to define here
//	public void show() {
//		System.out.println("Welcome");
//		
//	}
	
}


