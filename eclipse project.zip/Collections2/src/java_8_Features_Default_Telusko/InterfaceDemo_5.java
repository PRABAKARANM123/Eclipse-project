package java_8_Features_Default_Telusko;

public class InterfaceDemo_5 {
public static void main(String[] args) {
	// * With out creating object we can call show method by using class name
	K.show();
}
}

interface K {
	static void show() {
		System.out.println("Hi Java");
	}
}
