package java_8_Features_Default_Telusko;

public class InterfaceDemo_4 extends D implements I {
	public static void main(String[] args) {
		InterfaceDemo_4 obj = new InterfaceDemo_4();
		obj.show();
		// * in this case output should be class A
		// if have a class and also same method that class is first preference compare to Interface
	}
}

class D {
	public void show() {
		System.out.println("i am from A");
	}
}

interface I {
	default void show() {
		System.out.println("i am from 'I'");
	}
}

interface J {
	default void show() {
		System.out.println("i am from J");
	}
}
