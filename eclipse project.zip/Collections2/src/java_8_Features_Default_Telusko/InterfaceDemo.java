package java_8_Features_Default_Telusko;

public class InterfaceDemo implements A,B{
    // * When we simply diclar interface we can implements two interfaces
	public void show() {
		System.out.println("Hi");
	}

}

interface A {
	void show(); 
}

interface B {
	void show();
}
