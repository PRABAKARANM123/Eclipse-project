package java_8_Features_Default_Telusko;

public class InterfaceDemo_3 implements M, N {
	public static void main(String[] args) {
		InterfaceDemo_3 obj = new InterfaceDemo_3();
		obj.show();
	}

	// * when implement the two interfaces definitely we should implement main class also
	public void show() {
		// TODO Auto-generated method stub
		M.super.show();
	}

}

interface M {
	default void show() {
		System.out.println("Hi");
	}
}

interface N {
	default void show() {
		System.out.println("Hello");
	}
}
