package java_8_Feautres_forEach_Telusko;

import java.util.Arrays;
import java.util.List;

public class ForEachDemo {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(4, 5, 2, 8);
		
		list.forEach(x->System.out.println(x));
	}

}
