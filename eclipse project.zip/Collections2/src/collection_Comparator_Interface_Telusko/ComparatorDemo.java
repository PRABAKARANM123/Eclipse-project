package collection_Comparator_Interface_Telusko;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorDemo {
	public static void main(String[] args) {
		List<Integer> values = new ArrayList<>();
		values.add(586);
		values.add(751);
		values.add(468);
		values.add(524);
		
		Comparator com = new CompImp();
		
		Collections.sort(values, com);
		
		for(Integer i:values) {
			System.out.println(i);
		}
	}

}
