package collection_Comparator_Interface_Telusko;

import java.util.Comparator;

public class CompImp implements Comparator<Integer> {

	
	public int compare(Integer o1, Integer o2) {
		//if(o1>o2) // * comparison based on ascending order
		//if(o1%10>o2%10) // * comparison based on Last Number
		if(o1%10>o2%10) // * comparison based on Last Two Number
			return 1;
		else
		return -1;
	}

}
