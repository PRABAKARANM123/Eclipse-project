package collection_Comparator_Interface_Telusko;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InnerClassDemo_2 {
	public static void main(String[] args) {
		List<Integer> values = new ArrayList<>();
		values.add(856);
		values.add(586);
		values.add(751);
		values.add(468);
		values.add(524);
		
		Collections.sort(values, (o1, o2) ->
		{
			return o1%10>o2%10?1:-1;
		}
		);
		for(Integer i:values) {
			System.out.println(i);
		}
	}

}
