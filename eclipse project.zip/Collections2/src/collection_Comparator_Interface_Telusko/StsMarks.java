package collection_Comparator_Interface_Telusko;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StsMarks {
	public static void main(String[] args) {
		List<Student> sts = new ArrayList<>();
		sts.add(new Student(1, 65));
		sts.add(new Student(2, 85));
		sts.add(new Student(3, 95));
		sts.add(new Student(4, 78));
		sts.add(new Student(5, 82));
		
		Collections.sort(sts, (s1,s2)->
		{   // * print desending order
			return s1.marks>s2.marks?-1:s1.marks<s2.marks?1:0;
		});
		
		for(Student s:sts) {
			System.out.println(s);
		}
	}

}

class Student {
	int rollNo;
	int marks;
	
	public Student(int rollNo, int marks) {
		super();
		this.rollNo = rollNo;
		this.marks = marks;
	}
	
	public String toString() {
		return "Student [rollNo=" + rollNo + ", marks=" + marks + "]";
	}
	
	
}
