package java_8_LambdaExpression_Telusko;

interface Y {
	void show();
}

//class X implements Y {
	// * This class is do implemented function only 
	// * We implemented main class, so why we create new class for implementation 
	
//	public void show() {
//		System.out.println("Hello Java");
//	}
//}
public class LambdaDemo_2 {
	public static void main(String[] args) {
		A obj;
		obj = new A() { // * Anonymous inner class
			public void show() {
				System.out.println("Hello...");
			}
		};
		obj.show();
	}

}
