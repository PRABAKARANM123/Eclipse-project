package java_8_LambdaExpression_Telusko;

interface M {
	void show();
}

public class LambdaDemo_3 {
	public static void main(String[] args) {
		M obj;
		obj = ()->System.out.println("Hello--");
		obj.show();
	}

}

    // * this is the implementation of some interface M '()->System.out.println("Hello--");''
    // * ()->System.out.println("Hello--")  this is called Consumer interface 