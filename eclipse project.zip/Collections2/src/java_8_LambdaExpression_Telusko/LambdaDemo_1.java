package java_8_LambdaExpression_Telusko;

interface A {
	void show(int i);
}

class B implements A {
	public void show(int i) {
		System.out.println("Hello "+i);
	}
}

public class LambdaDemo_1 {
	public static void main(String[] args) {
		A obj;
		obj = new B();
		obj.show(5); // * we also pass the number
	}

}
