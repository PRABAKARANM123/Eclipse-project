package collection_Comparable_Interface_Telusko;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StsMarks {
	public static void main(String[] args) {
		List<Student> sts = new ArrayList<>();
		sts.add(new Student(1, 65));
		sts.add(new Student(2, 85));
		sts.add(new Student(3, 95));
		sts.add(new Student(4, 78));
		sts.add(new Student(5, 82));
		
		Collections.sort(sts);
		
		
		for(Student s:sts) {
			System.out.println(s);
		}
	}

}

class Student implements Comparable<Student>{
	int rollNo;
	int marks;
	
	public Student(int rollNo, int marks) {
		super();
		this.rollNo = rollNo;
		this.marks = marks;
	}
	
	public String toString() {
		return "Student [rollNo=" + rollNo + ", marks=" + marks + "]";
	}
	
	public int compareTo(Student s) {
		return this.marks>s.marks?-1:this.marks <s.marks?1:0;
	}
	
	
}
