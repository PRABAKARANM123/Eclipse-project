package innerClass_Telusko;

// * static inner class
public class X {
	static int i;
	static class Y {
		int j;
	}

}

class Z {
	public static void main(String[] args) {
		X.i=8;
		X.Y obj = new X.Y();
	}
}
