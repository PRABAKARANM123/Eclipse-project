package innerClass_Telusko;

// * Member class
public class A {
	int i;
	class B{
		int j;
		public void show() {
			System.out.println("Hollow");
		}
	}

}
class c{
	public static void main(String[] args) {
		A obj = new A();
		obj.i = 5;
		A.B obj1 = obj.new B(); // * by using this we can call inner class 
		obj1.j=8;
		obj1.show();
	
	}
}
