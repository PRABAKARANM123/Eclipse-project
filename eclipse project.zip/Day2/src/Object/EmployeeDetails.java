package Object;

public class EmployeeDetails {
	public static void main(String[]args)
	{
		Employee e1=new Employee();
		e1.name="PRABAKARAN";
		e1.id="13ME110";
		e1.dateOfBirth="19.04.1995";
		e1.age=27;
		e1.exp=3;
		e1.salary=45000;
		e1.bGroup="O+"
;
		System.out.println(e1.name);
		System.out.println(e1.id);
		System.out.println(e1.dateOfBirth);
		System.out.println(e1.age);
		System.out.println(e1.exp);
		System.out.println(e1.salary);
		System.out.println(e1.bGroup);
		
		
		
		
	}

}
