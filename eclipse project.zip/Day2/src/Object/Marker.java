package Object;

public class Marker {
	String colour;
	int size;
	float capSize;
	String inkColur;
	String brand;
	int price;
	float weight;
	String usage;
    String lableColour;
	

}
