package Object;

public class Bike {
	
	String brand;
	int price;
	String colour;
	int discountAmount;
	boolean isTubeLess;
	int netPrice;
	

}
