package Object;

public class Employee {
	String name;
	String id;
	String dateOfBirth;
	int age;
	int exp;
	int salary;
	String bGroup;
	

}
