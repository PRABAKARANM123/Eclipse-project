package Object;

public class UseMobile {
	public static void main(String[]args)
	{
	Mobile m1=new Mobile();
	m1.brand="mi";
	m1.colour="black";
	m1.price=20000;
	m1.height=12.5f;
	m1.weight=100;
	m1.os="android";
	System.out.println(m1.brand);
	System.out.println(m1.colour);
	System.out.println(m1.price);
	System.out.println(m1.height);
	System.out.println(m1.weight);
	System.out.println(m1.os);
	}
	
	
	

}
