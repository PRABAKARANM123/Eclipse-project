package Object;

public class UseMarker {
	public static void main(String[]args)
	{
		Marker m1=new Marker();
		m1.colour="RED";
		m1.size=2;
		m1.capSize=2.5f;
		m1.inkColur="blue";
		m1.brand="Rorito";
		m1.price=25;
		m1.weight=100;
		m1.usage="writting";
		m1.lableColour="black";
		System.out.println(m1.colour);
		System.out.println(m1.size);
		System.out.println(m1.capSize);
		System.out.println(m1.inkColur);
		System.out.println(m1.brand);
		System.out.println(m1.price);
		System.out.println(m1.weight);
		System.out.println(m1.usage);
		System.out.println(m1.lableColour);
		
		
		
		
		
		
		
		
		
		
	}

}
