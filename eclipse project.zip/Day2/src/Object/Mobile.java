package Object;

public class Mobile {
	String brand;
	String colour;
	int price;
	String os;
	float height;
	double weight;
	
	
	

}
