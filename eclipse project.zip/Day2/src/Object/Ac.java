package Object;

public class Ac {
	String brand;
	String colour;
	int price;
	float taxAmount;
	float netAmount;
	float taxPercent;

}
