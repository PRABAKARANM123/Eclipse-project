package Object;

public class Pencile {
	String brand;
	int price;
	float taxAmount;
	int discountAmount;
	float netPrice;
	

}
