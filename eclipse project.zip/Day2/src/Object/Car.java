package Object;

public class Car {

	
		String brand;
		int price;
		String colour;
		int taxAmount;
		boolean  isAirBags;
		int netPrice;
	    

}
