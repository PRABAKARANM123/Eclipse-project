package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FixedSizeListDemo {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(new Integer[5]);
		System.out.println(list);
		list.add(41); // it throws UnsupportedOperationException
		
		

	}
}


