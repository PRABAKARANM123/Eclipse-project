package com.example.sort_arraylist;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortDemo2 {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("Ram", "Kavi", "Prabu", "Arun");
		Collections.sort(list);
		System.out.println(list);
		
		Collections.reverse(list);
		System.out.println(list);
		
		System.out.println(Collections.max(list));
		System.out.println(Collections.min(list));
		
		list.add("MSP");
		System.out.println(list);
	}
}
