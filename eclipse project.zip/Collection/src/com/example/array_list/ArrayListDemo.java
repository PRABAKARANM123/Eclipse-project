package com.example.array_list;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class ArrayListDemo {
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(10);
		list.add(30);
		list.add(40);
		list.add(30);
		System.out.println(list);
		System.out.println("------Using StreamApi------");
		List<Integer> newList = list.stream().distinct().collect(Collectors.toList());
		System.out.println(newList);
		
		System.out.println("------Using Set------");
		System.out.println(list);
        Set<Integer> set = new HashSet<>(list);
        System.out.println(set);
        List<Integer> list2 = new ArrayList<>(set);
        System.out.println("WithOut Duplicate"+list2);
        
        System.out.println("------Using For Loop------");
        List<Integer>newList1 = new ArrayList<>();
        for(Integer values : list) {
        	if(!newList1.contains(values)) {
        		newList1.add(values);
        	}
        }
        System.out.println(newList1);
        
	}

}
