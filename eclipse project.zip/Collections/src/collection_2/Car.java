package collection_2;

public class Car {

}
