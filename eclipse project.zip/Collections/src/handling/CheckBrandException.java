package handling;

public class CheckBrandException extends Exception {
	public CheckBrandException(String msg) {
	super(msg);
	}

}
