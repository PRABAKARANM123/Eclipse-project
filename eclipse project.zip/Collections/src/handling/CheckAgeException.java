package handling;

public class CheckAgeException extends Exception {
	public CheckAgeException(String msg) {
		super (msg);
	}

}
