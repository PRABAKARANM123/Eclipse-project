package handling;

public class CheckMailException extends Exception {
	public CheckMailException(String msg) {
		super(msg);
	}

}
