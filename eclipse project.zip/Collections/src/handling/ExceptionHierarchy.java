package handling;

public class ExceptionHierarchy {
	public static void main(String[] args) {
		int[] nums = {0,12,34,9,4,8,5};
		try {
	}

}
