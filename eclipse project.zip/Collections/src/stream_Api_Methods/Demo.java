package stream_Api_Methods;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Demo {
	public static void main(String[] args) {
		
	List<String> strings = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
	List<String> filtered = strings.stream().filter(string -> !string.isEmpty()).collect(Collectors.toList());
	System.out.println(strings);
	System.out.println(filtered);
	
	Iterable<Object> stsList = Arrays.asList("Ram", 23, "Kavi", " ", "Prabau");
	
	System.out.println(stsList);
	}

}
