package stream_Api_Methods;

import java.util.ArrayList;
import java.util.List;

public class UseProduct {
	public static void main(String[] args) {
		List<Product> proList = new ArrayList<>();
		proList.add(new Product(1, "Hp Laptop", 50000));
		proList.add(new Product(2, "Dell Laptop", 42000));
		proList.add(new Product(3, "Lenovo Laptop", 45000));
		proList.add(new Product(4, "SonyLaptop", 43000));
		proList.add(new Product(5, "Apple Laptop", 60000));
		
		List<Integer> priceList = new ArrayList<>();
		for(Product pro: proList) {
			if(pro.price<45000) {
				priceList.add(pro.price);
			}
		}
		System.out.println(priceList);
	}

}
