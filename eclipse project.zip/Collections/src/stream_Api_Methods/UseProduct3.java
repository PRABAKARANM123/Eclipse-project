package stream_Api_Methods;

import java.util.ArrayList;
import java.util.List;

public class UseProduct3 {
	public static void main(String[] args) {
		List<Product> proList = new ArrayList<>();
		proList.add(new Product(1, "Hp Laptop", 50000));
		proList.add(new Product(2, "Dell Laptop", 42000));
		proList.add(new Product(3, "Lenovo Laptop", 45000));
		proList.add(new Product(4, "SonyLaptop", 43000));
		proList.add(new Product(5, "Apple Laptop", 60000)); 
	         totalPrice = productsList.stream().map(product->product.price).reduce(0.0f,(sum, price)->sum+price);   // accumulating price  
	        System.out.println(totalPrice);  
	        
	        float totalPrice2 = productsList.stream()  
	                .map(product->product.price)  
	                .reduce(0.0f,Float::sum);   // accumulating price, by referring method of Float class  
	        System.out.println(totalPrice2);  
	          
	    }  
	

}
