package stream_Api_Methods;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import collection_3.Employee;

public class UseProduct2 {
	public static void main(String[] args) {
//		List<Product> proList = new ArrayList<>();
//		proList.add(new Product(1, "Hp Laptop", 50000));
//		proList.add(new Product(2, "Dell Laptop", 42000));
//		proList.add(new Product(3, "Lenovo Laptop", 45000));
//		proList.add(new Product(4, "SonyLaptop", 43000));
//		proList.add(new Product(5, "Apple Laptop", 60000));
//		
		List<Product> productList = Arrays.asList(
				new Product(1, "Hp Laptop", 50000), 
				new Product(2, "Dell Laptop", 42000), 
				new Product(3, "Lenovo Laptop", 45000), 
				new Product(5, "Apple Laptop", 60000));
		
		//List<Product> productList = proList.stream().filter(x->x.price>45000).collect(Collectors.toList());
		//productList.forEach(a->System.out.println(a));
		//proList.stream().filter(x->x.getPrice()>45000).collect(Collectors.toList()).forEach(a->System.out.println(a));;
		
		List<Product> l=productList.stream().filter(x->x.getPrice()>50000).collect(Collectors.toList());
		for(Product e: l) {
		System.out.println(e);
		}
		
		
	}	
}
	