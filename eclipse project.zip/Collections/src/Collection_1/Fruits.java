package Collection_1;

import java.util.ArrayList;

public class Fruits {
	public static void main(String[] args) {
		ArrayList<String> li = new ArrayList<>();
		li.add("Banana");
		li.add("Grapes");
		li.add("Apple");
		li.add("Mango");
//		System.out.println(li);
//		System.out.println(li.size());
//		System.out.println("---------------before removing---------------");
//		li.remove(2);
//		System.out.println(li);
//		System.out.println("---------------before updating---------------");
//		
//		li.set(0,"Apple");
//
//		System.out.println(li);
		
		System.out.println(li.get(1));
		
	
		System.out.println(li.size());
		
	}
}
