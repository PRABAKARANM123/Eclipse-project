package CollectionDemo;

public class Demo {
	
	public static void main(String[] args) {
		System.out.println("HolloWorld");
				
	}
	static {
		System.out.println("Hollo");
	}
	
	

}
