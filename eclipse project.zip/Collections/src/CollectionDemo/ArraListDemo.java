package CollectionDemo;

import java.util.ArrayList;

public class ArraListDemo {
	public static void main(String[] args) {
		int a = 5;
		ArrayList<Integer> al = new ArrayList<>();
		for(int i=0; i<=a; i++) {
			al.add(i);
			
		}
		
		System.out.println(al);
		al.ensureCapacity(100);
		al.remove(3);
		al.add(1, null);
		System.out.println(al);
		al.set(3, 0);
		System.out.println(al);
		for(int i=0; i<al.size(); i++) {
			System.out.print(al.get(i)+" ");
		}
	}

}
