package CollectionDemo;

import java.util.ArrayList;

public class ArrayListDemo_1 {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<> ();
		list.add("Ram");
		list.add("Kavi");
		list.add("Prabu");
		list.add("Rai");
		list.add("muthu");
		System.out.println(list);
		list.removeAll(list);
		System.out.println(list);
		list.retainAll("");
		System.out.println(list);
		
	}

}
