package for2and3;

public class Car {
	String brand;
	int price;
	String colour;

}
