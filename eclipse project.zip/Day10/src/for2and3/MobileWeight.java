package for2and3;

public class MobileWeight {
	public static void main(String[] args) {
		float[] weight = new float[4];
		weight[0]=14.5f;
		weight[1]= 15.2f;
		weight[2]=16.3f;
		weight[3]=17.8f;
		for(int i=0; i<weight.length; i++) {
			System.out.println(weight[i]);
		}
	}

}
