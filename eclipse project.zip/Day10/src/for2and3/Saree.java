package for2and3;

public class Saree {
	String material;
	String colour;
	int price;
	int discountAmount;
	
}
