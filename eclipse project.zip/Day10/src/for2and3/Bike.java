package for2and3;

public class Bike {
	String brand;
	int price;
	String colour;
	int taxAmount;

}
