package for2and3;

public class Marker {
	public static void main(String[] args) {
		int[] prices = {30,45,25,50};
		for(int i=0; i<prices.length/2; i++) {
			System.out.println(prices[i]);
		}
	}

}
