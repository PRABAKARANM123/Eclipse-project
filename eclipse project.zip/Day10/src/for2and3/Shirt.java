package for2and3;

public class Shirt {
	String brand;
	int price;
	String colour;
	boolean isChecked;
	int discountAmount;
	int netPrice;

}
