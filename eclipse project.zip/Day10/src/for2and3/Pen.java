package for2and3;

public class Pen {
	String brand;
	int price;
	String colour;
	boolean isRefillable;
	

}
