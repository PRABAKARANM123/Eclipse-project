package composition;

public class Engine {
	String brand;
	int price;
	int enginecc;

}
