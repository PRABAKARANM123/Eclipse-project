package composition;

public class Computer {
	String brand;
	int price;
	String color;
	Cpu cpu;

}
