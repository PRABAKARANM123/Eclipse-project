package composition;

public class Cpu {
	String brand;
	int price;
	int rom;

}
