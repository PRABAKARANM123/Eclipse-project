package composition;

public class Car {
	String brand;
	int price;
	String color;
	Engine engine;

}
