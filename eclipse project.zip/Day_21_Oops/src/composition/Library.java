package composition;

public class Library {
	String type;
	String location;
	Book book;

}
