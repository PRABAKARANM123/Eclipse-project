package compositionRivice;

public class Mobile {
	String brand;
	String color;
	int price;
	Processor processor;
}


