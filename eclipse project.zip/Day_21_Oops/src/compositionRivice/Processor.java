package compositionRivice;

public class Processor {
	String brand;
	int price;
	int aScore;

}
