package compositionRivice;

public class Cpu {
	int ram;
	String brand;
	String MotherBoard;

}
