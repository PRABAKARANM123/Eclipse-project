package compositionRivice;

public class Computer {
	String brand;
	String monitorType;
	boolean isWindows;
	Cpu cpu;

}
