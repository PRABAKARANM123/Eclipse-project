package encapsulationRivice;

public class UseChair {
	public static void main(String[] args) {
		Chair chair1 = new Chair(4, "Wood", false);
		Chair chair2 = new Chair(3, "Plastic", true);
		System.out.println(chair1);
	}

}
