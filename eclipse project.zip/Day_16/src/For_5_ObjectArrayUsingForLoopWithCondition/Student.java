package For_5_ObjectArrayUsingForLoopWithCondition;

public class Student {
	String name;
	int rollNo;
	String std;
	String section;

}
