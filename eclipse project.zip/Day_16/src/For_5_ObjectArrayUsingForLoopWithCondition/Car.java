package For_5_ObjectArrayUsingForLoopWithCondition;

public class Car {
	String brand;
	int price;
	String model;

}
