package For_5_ObjectArrayUsingForLoopWithCondition;

public class Mobile {
	String brand;
	int price;
	String model;
	boolean isTouchScreen;

}
