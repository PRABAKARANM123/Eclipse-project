package For_5_ObjectArrayUsingForLoopWithCondition;

public class Marker {
	String brand;
	int price;
	String color;
	boolean isRefillable;

}
