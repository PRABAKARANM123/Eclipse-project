package For_5_ObjectArrayUsingForLoopWithCondition;

public class Laptop {
	String brand;
	int price;
	String model;
	boolean isTouchScreen;
	int netPrice;

}
