package For_5_ObjectArrayUsingForLoopWithCondition;

public class Bag {
	String brand;
	String bagType;
	int price;
	boolean isWaterProof;

}
