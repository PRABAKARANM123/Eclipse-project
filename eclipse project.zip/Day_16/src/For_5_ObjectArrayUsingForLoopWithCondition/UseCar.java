package For_5_ObjectArrayUsingForLoopWithCondition;

public class UseCar {
	public static void main(String[] args) {
		Car car1 = new Car();
		car1.brand = "TATA";
		car1.price = 500000;
		car1.model = "X-";
		
		Car car2 = new Car();
		car2.brand = "BMW";
		car2.price = 2000000;
		car2.model = "A6";
		
		Car car3 = new Car();
		car3.brand = "MARUTHI";
		car3.price = 600000;
		car3.model = "ZXI";
		
		Car[] cars = {car1,car2,car3};
//		Car max = null;
//		int max1=0;
//		for(int i=0; i<cars.length; i++) {
//			if(cars[i].brand.length()>max1) {
//				max = cars[i];
//				
//				
//			}
//		}
//		System.out.println(max.brand);
//		
		
	}

}
